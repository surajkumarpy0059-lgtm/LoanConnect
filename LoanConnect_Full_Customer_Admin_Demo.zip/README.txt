LoanConnect Full Demo
=====================
Customer + Admin browser prototype.

Customer:
- 12 loan categories
- Loan application form
- Application ID and status
- My Applications
- CIBIL demo screen with consent wording

Admin:
- Dashboard
- Applications
- Customers
- Leads
- Status management
- Data stored locally in browser for demo

IMPORTANT FOR PRODUCTION:
This is a front-end prototype, not a production lending system. Real deployment needs a secure backend/database, authentication and role-based access, document storage, audit logs, privacy/security controls, lender integrations, and an authorized credit-bureau/CIBIL integration with customer consent and required compliance. Do not collect real identity/financial documents in this demo.
